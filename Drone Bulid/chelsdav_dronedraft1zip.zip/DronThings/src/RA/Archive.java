package RA;

public class Archive {
	private Report[] archivelog;
	private int dailyDeliver;
	 
	public Archive() {
		setArchivelog(new Report[100]);
		this.setDailyDeliver(0);
	}
    public void setArchiveEntry(int index, Report r) {
     archivelog[index] = r;
     this.setDailyDeliver(this.getDailyDeliver()+1);
    }
	
	public Report getArchiveEntry(int index) {
		return archivelog[index];
	}
	public Report[] getAR() {
		return archivelog;
	}

	public void setArchivelog(Report[] archivelog) {
		this.archivelog = archivelog;
	}
	public int getDailyDeliver() {
		return dailyDeliver;
	}
	public void setDailyDeliver(int dailyDeliver) {
		this.dailyDeliver = dailyDeliver;
	}

}
