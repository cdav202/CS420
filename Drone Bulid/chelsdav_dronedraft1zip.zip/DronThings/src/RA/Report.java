package RA;

public class Report {
	private String name; 
	private String Add;
	private int coords;
	private String DateTime;
	private String OrderNum;
	private String MedType;
	
	public Report(String n, String a, int c, String d, String o, String m) {
		this.setName(n);
		this.setAdd(a);
		this.setCoords(c);
		this.setDateTime(d);
		this.setOrderNum(o);
		this.setMedType(m);
	}
	public String toString() {
		String report = "Name: " + this.getName() + "Order: " + this.getOrderNum() + "Medication: " + this.getMedType()  + "Address: " + this.getAdd() + "/" + this.getCoords() + " Date Delivered: " + this.getDateTime();
        return report;	
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return Add;
	}
	public void setAdd(String add) {
		Add = add;
	}
	public int getCoords() {
		return coords;
	}
	public void setCoords(int coords) {
		this.coords = coords;
	}
	public String getDateTime() {
		return DateTime;
	}
	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
	public String getOrderNum() {
		return OrderNum;
	}
	public void setOrderNum(String orderNum) {
		OrderNum = orderNum;
	}
	public String getMedType() {
		return MedType;
	}
	public void setMedType(String medType) {
		MedType = medType;
	}
}
