package pharmaDrone;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import tellolib.control.TelloControl;
import tellolib.drone.TelloDrone;
public class TDrone {
	private ArrayList<Integer> destinationCoords;
	private ArrayList<Integer> homeCoords;
	private boolean DeliverFlag;
	private boolean stopFlight;
	TelloControl telloControl;
	TelloDrone drone;
	private final Logger logger;
	public TDrone() {
         telloControl = TelloControl.getInstance();
	     drone = TelloDrone.getInstance();
	     destinationCoords = new ArrayList<Integer>();
	     homeCoords = new ArrayList<Integer>();
	     DeliverFlag = false;
	     stopFlight = false;
	     telloControl.connect();
	     logger = Logger.getGlobal(); 
	   
	}
	public void takeOff() {
	logger.info("start");
	 telloControl.setLogLevel(Level.FINE);
	 telloControl.startStatusMonitor();
	 telloControl.enterCommandMode();
	 telloControl.takeOff();
		
		
	}
	
	public void Deliver(DroneIcon dot, Integer f, Integer b, Integer l, Integer r, Integer u, Integer d) {
		DeliverFlag = true;
		
		telloControl.forward(f);
	    homeCoords.add(f);
		
	    
	    telloControl.backward(b);
	    homeCoords.add(b);
	    
	   
	    telloControl.up(u);
	    homeCoords.add(u);
	    
	
	    telloControl.down(d);
	    homeCoords.add(d);
	    
	   
	    telloControl.left(l);
	    homeCoords.add(l);
	    
	    
	    telloControl.right(r);
	    homeCoords.add(r);
	 //   dot.checkDroneDirections(r, "right");
	    telloControl.land();
	    Return(f, b, l, r, u, d);
	    
		}
		
	    
	
	
	public void Return(Integer b, Integer f, Integer r, Integer l, Integer d, Integer u) {
		telloControl.enterCommandMode();
        telloControl.startStatusMonitor();
		telloControl.takeOff();
		telloControl.forward(f);
	    homeCoords.add(f);
	    telloControl.backward(b);
	    homeCoords.add(b);
	    telloControl.up(u);
	    homeCoords.add(u);
	    telloControl.down(d);
	    homeCoords.add(d);
	    telloControl.left(l);
	    homeCoords.add(l);
	    telloControl.right(r);
	    homeCoords.add(r);
	    telloControl.land();
	    telloControl.disconnect();
		
	}
	
	public void FinishDelivery() {
		DeliverFlag = false;
		
	}
	public TelloControl getTC() {
		return telloControl;
	}
	
	public ArrayList<Integer> getDestCoords() {
		return destinationCoords;
	}
	public void setDestCoords(ArrayList<Integer> destCoords) {
		destinationCoords = destCoords;
	}
	public ArrayList<Integer> gethomeCoords() {
		return homeCoords;
	}
	public void sethomeCoords(ArrayList<Integer> hc) {
		homeCoords = hc;
	}
	public boolean isDeliverFlag() {
		return DeliverFlag;
	}
	public void setDeliverFlag(boolean deliverFlag) {
		DeliverFlag = deliverFlag;
	}
	public void setstopFlight(boolean emergency) {
		stopFlight = emergency;
	}
	public Logger getLog() {
		return logger;
	}
	

	}


