package pharmaDrone;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JComponent;

public class DroneIcon extends JComponent {
	public DroneIcon(int x, int y) {
		setSize(415,160);
		setVisible(true);
	}
	
	//draws a red circle that represents the drone's starting point
		public void paint (Graphics droneIcon){
			droneIcon.setColor(Color.red);
			//FIX THIS INSERT X AND Y BUT NUMBERS HERE ARE FOR TESTING
			//X and Y not seeming to work
			droneIcon.fillOval(getX(), getY(), 7, 7);
		}
		
	public void checkDroneDirections(Integer cm, String direction) {
		int px= convertCMtoPX(cm);
		switch(direction) {
		case "up":
			this.translate(getX(), getY()+px);
			break;
		case "down":
			this.translate(getX(), getY()-px);
		case "left":
			this.translate(getX()-px, getY());
		case "right":
			this.translate(getX()+px, getY());
		}
		
	}
	
	public int convertCMtoPX(Integer cm) {
		int moveByPx=(cm/2);
		return moveByPx;
	}
	
	
}
