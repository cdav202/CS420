package pharmaDrone;


import javax.swing.table.AbstractTableModel;

public class ArcTableModel extends AbstractTableModel {
   private Archive mainArchive;
   private String[] columnTitles = new String[] {"Name", "Address", "Coords", "DateTime", "OrderNum", "MedType"};
    public ArcTableModel(Archive arc) {
    	this.mainArchive = arc;
    }
    public Archive getArc() {
    	return mainArchive;
    }
	
    @Override
 	  public String getColumnName(int column) {
 	        return columnTitles[column];
 	    }
     
    @Override
	public int getRowCount() {
		return mainArchive.getSize();

	}

	@Override
	public int getColumnCount() {
		return columnTitles.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Report selectedReport = getArc().getArchiveEntry(rowIndex);
		switch (columnIndex) {
        case 0:
            return selectedReport.getName();
        case 1:
            return selectedReport.getAddress();
        case 2:
            return selectedReport.getCoords();
        case 3:
            return selectedReport.getDateTime();
        case 4:
            return selectedReport.getOrderNum();
        case 5:
            return selectedReport.getMedType();
      
    }
		return null;
	}

}
