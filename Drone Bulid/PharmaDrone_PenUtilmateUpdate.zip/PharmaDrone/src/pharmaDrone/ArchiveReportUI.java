package pharmaDrone;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArchiveReportUI {

	private JFrame frame;
	private JTable table;
	private ArcTableModel archiveTable;
	private Archive deliveryArchive;

	/**
	 * Launch the application.
	 */
	public static void NewFrame(Archive A) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArchiveReportUI window = new ArchiveReportUI(A);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
  public JFrame getFrame() {
	  return frame;
  }
	/**
	 * Create the application.
	 */
	public ArchiveReportUI(Archive Arc) {
		deliveryArchive = Arc;
		archiveTable = new ArcTableModel(deliveryArchive);
		
		initialize();
	}
	public Archive getdeliveryArchive() {
		return deliveryArchive;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 764, 412);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.getTableHeader().setOpaque(false);
		table.getTableHeader().setBackground(Color.lightGray);
		table.setAutoCreateRowSorter(true);
		table.setModel(archiveTable);
	
		scrollPane.setViewportView(table);
		
		JButton backButton = new JButton("Back");
		backButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		backButton.setBounds(10, 434, 89, 23);
		frame.getContentPane().add(backButton);
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					frame.dispose();
				}
			});
	}
}
