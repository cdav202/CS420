package pharmaDrone;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JComponent;

public class destinationIcon extends JComponent {
	public destinationIcon(int x, int y) {
			setSize(415,160);
			setVisible(true);
		}
		
		//draws a pink sqaure in the middle of the grid that represent a home icon
		public void paint (Graphics destination) {
			destination.setColor(Color.pink);
			destination.fillRect(380,100, 10, 10);
			
		}
		
}
