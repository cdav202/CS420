package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.Label;
import java.awt.GridLayout;
import javax.swing.JScrollPane;

public class PharmaDroneUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField coordinateTextBox;
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void startProgram( ) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PharmaDroneUI frame = new PharmaDroneUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PharmaDroneUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel droneMap = new JPanel();
		droneMap.setForeground(new Color(0, 0, 0));
		droneMap.setBackground(new Color(0, 0, 0));
		droneMap.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		droneMap.setBounds(10, 41, 764, 160);
		contentPane.add(droneMap);
		droneMap.setLayout(null);
		
		//creates and adds a grid to the droneMap
		Grid newGrid= new Grid();
		newGrid.setBounds(0, 0, 764, 160);
		droneMap.add(newGrid);
		
		//creates a home icon where the pharmacy is located
		PharmaIcon homeIcon= new PharmaIcon();
		homeIcon.setBounds(0, 0, 764, 160);
		droneMap.add(homeIcon);
		
		//creates a drone location icon
		//FIX AS FIXED POINTS ARE FOR TESTING
		DroneIcon droneIcon= new DroneIcon(300,300);
		droneIcon.setBounds(0, 0, 764, 160);
		droneMap.add(droneIcon);
		
		//creates a destinationIcon 
		destinationIcon destinationIconn= new destinationIcon(300,300);
		destinationIconn.setBounds(0, 0, 764, 160);
		droneMap.add(destinationIconn);
		
		JButton deliverButton = new JButton("Deliver\r\n");
		deliverButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		deliverButton.setBounds(210, 316, 100, 50);
		contentPane.add(deliverButton);
		
		coordinateTextBox = new JTextField();
		coordinateTextBox.setBackground(new Color(255, 255, 255));
		coordinateTextBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		coordinateTextBox.setHorizontalAlignment(SwingConstants.CENTER);
		coordinateTextBox.setText("\r\n");
		coordinateTextBox.setBounds(10, 239, 300, 35);
		contentPane.add(coordinateTextBox);
		coordinateTextBox.setColumns(10);
		
		JButton logoutButton = new JButton("Logout");
		logoutButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		logoutButton.setBounds(10, 11, 100, 21);
		contentPane.add(logoutButton);
		
		JPanel seperator = new JPanel();
		seperator.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		seperator.setBackground(new Color(170, 171, 191));
		seperator.setBounds(340, 212, 4, 210);
		contentPane.add(seperator);
		
		JButton returnButton = new JButton("Return\r\n");
		returnButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		returnButton.setBounds(10, 316, 100, 50);
		contentPane.add(returnButton);
		
		Label coordinateLabel = new Label("Please enter coordinates:");
		coordinateLabel.setBounds(10, 212, 145, 21);
		contentPane.add(coordinateLabel);
		
		Label messageLogBox = new Label("Message Log:");
		messageLogBox.setBounds(350, 212, 76, 21);
		contentPane.add(messageLogBox);
		
		JButton archiveButton = new JButton("Archive");
		archiveButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		archiveButton.setBounds(674, 11, 100, 21);
		contentPane.add(archiveButton);
		//creates the ArchiveInfo Page
		archiveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArchiveInfoInsertion reportArchiveInfoPage= new ArchiveInfoInsertion();
				reportArchiveInfoPage.NewFrame();
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(354, 239, 420, 183);
		contentPane.add(scrollPane_1);
		
		JTextPane messageBox = new JTextPane();
		scrollPane_1.setViewportView(messageBox);
		messageBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
	}
}
