package pharmaDrone;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;

public class PharmaIcon extends JComponent {
	public PharmaIcon() {
		setSize(415,160);
		setVisible(true);
	}
	
	//draws a yellow sqaure in the middle of the grid that represent a home icon
	public void paint (Graphics home) {
		home.setColor(Color.yellow);
		home.fillRect(380,80, 10, 10);
		
	}
}
