package pharmaDrone;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class ArchiveReportUI {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void NewFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArchiveReportUI window = new ArchiveReportUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ArchiveReportUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 764, 439);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.getTableHeader().setOpaque(false);
		table.getTableHeader().setBackground(Color.lightGray);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				//can delete or add to the table have a function to add to this from your database
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"First Name", "Last Name", "Street Address", "Coordinate", "Order Number", "Medicine Type"
			}
		));
		scrollPane.setViewportView(table);
		
	}
}
