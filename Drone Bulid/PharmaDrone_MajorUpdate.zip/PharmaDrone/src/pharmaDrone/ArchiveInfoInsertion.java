package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

public class ArchiveInfoInsertion {

	private JFrame frame;
	private int MostRecentDeli;
	private JTextField firstNameInput;
	private JTextField lastNameInput;
	private JTextField streetAddressInput;
	private JTextField orderNumberInput;
	private JTextField medicineTypeInput;
    private Archive CentralArc = new Archive();
	/**
	 * Launch the application.
	 */
	public static void NewFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArchiveInfoInsertion window = new ArchiveInfoInsertion();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public JFrame getF() {
		  return frame;
	  }
	/**
	 * Create the application.
	 */
	public ArchiveInfoInsertion() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel titleLabel = new JLabel("Patient Information Entry");
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 20));
		titleLabel.setBounds(250, 11, 286, 25);
		frame.getContentPane().add(titleLabel);
		
		JLabel lastNameLabel = new JLabel("Date");
		lastNameLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 15));
		lastNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lastNameLabel.setBounds(39, 220, 103, 14);
		frame.getContentPane().add(lastNameLabel);
		
		firstNameInput = new JTextField();
		firstNameInput.setBounds(39, 170, 312, 39);
		frame.getContentPane().add(firstNameInput);
		firstNameInput.setColumns(10);
		
		JLabel firstNameLabel_1 = new JLabel("First Name");
		firstNameLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		firstNameLabel_1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 15));
		firstNameLabel_1.setBounds(39, 120, 103, 14);
		frame.getContentPane().add(firstNameLabel_1);
		
		lastNameInput = new JTextField();
		lastNameInput.setColumns(10);
		lastNameInput.setBounds(39, 270, 312, 35);
		frame.getContentPane().add(lastNameInput);
		
		JLabel streetAddressLabel = new JLabel("Street Address");
		streetAddressLabel.setHorizontalAlignment(SwingConstants.CENTER);
		streetAddressLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 15));
		streetAddressLabel.setBounds(39, 320, 137, 14);
		frame.getContentPane().add(streetAddressLabel);
		
		streetAddressInput = new JTextField();
		streetAddressInput.setColumns(10);
		streetAddressInput.setBounds(39, 370, 312, 35);
		frame.getContentPane().add(streetAddressInput);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBackground(new Color(128, 128, 128));
		separator.setBounds(400, 120, 8, 330);
		frame.getContentPane().add(separator);
		
		JLabel orderNumberLabel = new JLabel("Order Number");
		orderNumberLabel.setHorizontalAlignment(SwingConstants.CENTER);
		orderNumberLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 15));
		orderNumberLabel.setBounds(418, 122, 117, 14);
		frame.getContentPane().add(orderNumberLabel);
		
		orderNumberInput = new JTextField();
		orderNumberInput.setColumns(10);
		orderNumberInput.setBounds(418, 170, 312, 39);
		frame.getContentPane().add(orderNumberInput);
		
		JLabel medicineTypeLabel = new JLabel("Medicine Type");
		medicineTypeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		medicineTypeLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 15));
		medicineTypeLabel.setBounds(418, 222, 117, 14);
		frame.getContentPane().add(medicineTypeLabel);
		
		medicineTypeInput = new JTextField();
		medicineTypeInput.setColumns(10);
		medicineTypeInput.setBounds(418, 266, 312, 39);
		frame.getContentPane().add(medicineTypeInput);
		
		JLabel messageLabel = new JLabel("The coordinates were pre-entered.");
		messageLabel.setForeground(new Color(128, 128, 128));
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		messageLabel.setFont(new Font("Arial Rounded MT Bold", Font.ITALIC, 12));
		messageLabel.setBounds(418, 322, 324, 56);
		frame.getContentPane().add(messageLabel);
		
		JLabel directionLabel = new JLabel("Please enter inputs for the fields below.");
		directionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		directionLabel.setForeground(Color.GRAY);
		directionLabel.setFont(new Font("Arial Rounded MT Bold", Font.ITALIC, 12));
		directionLabel.setBounds(260, 47, 260, 39);
		frame.getContentPane().add(directionLabel);
		
		JButton enterButton = new JButton("Enter");
		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				MostRecentDeli = 4;
				Report r = new Report(firstNameInput.getText(), streetAddressInput.getText(), getMostRecentDeli(), lastNameInput.getText(), orderNumberInput.getText(), medicineTypeInput.getText());
				CentralArc.addArchiveEntry(r);
				ArchiveReportUI reportArchive= new ArchiveReportUI(CentralArc);
				
				reportArchive.getF().setVisible(true);
			}
		});
		enterButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 15));
		enterButton.setBounds(617, 400, 125, 50);
		frame.getContentPane().add(enterButton);
	}

	public int getMostRecentDeli() {
		return MostRecentDeli;
	}

	public void setMostRecentDeli(int mostRecentDeli) {
		MostRecentDeli = mostRecentDeli;
	}
}
