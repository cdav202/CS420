package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameTextfield;
	private JTextField passwordTextfield;

	/**
	 * Launch the application.
	 */
	public static void NewFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel passwordLabel = new JLabel("Enter Password:");
		passwordLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		passwordLabel.setBounds(80, 140, 97, 14);
		contentPane.add(passwordLabel);
		
		usernameTextfield = new JTextField();
		usernameTextfield.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		usernameTextfield.setBounds(80, 109, 235, 20);
		contentPane.add(usernameTextfield);
		usernameTextfield.setColumns(10);
		
		JLabel usernameLabel = new JLabel("Enter Username:");
		usernameLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		usernameLabel.setBounds(80, 84, 108, 14);
		contentPane.add(usernameLabel);
		
		passwordTextfield = new JTextField();
		passwordTextfield.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		passwordTextfield.setColumns(10);
		passwordTextfield.setBounds(80, 165, 235, 20);
		contentPane.add(passwordTextfield);
		
		JLabel loginLabel = new JLabel("Log In");
		loginLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
		loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
		loginLabel.setBounds(157, 35, 89, 25);
		contentPane.add(loginLabel);
		JButton loginButton = new JButton("login");
		loginButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		loginButton.setBounds(157, 210, 89, 23);
		contentPane.add(loginButton);
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				String username= "PharmaDroneUserIDNumber";
				String password= "TestingAccount12345";
				PharmaDroneUI mainWin= new PharmaDroneUI();
				mainWin.NewFrame();
//				if ((usernameTextfield.getText()==username) && (passwordTextfield.getText()==password)){
//				}
				
			}
		});
	}
}
