package pharmaDrone;

import tellolib.*;
import tellolib.communication.TelloConnection;
import tellolib.control.TelloControl;
import tellolib.drone.TelloDrone;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class TDrone {
	private ArrayList<Integer> DestCoords;
	private ArrayList<Integer> HomeCoords;
	private boolean DeliverFlag;
	private boolean StopFlight;
	TelloControl telloControl;
	TelloDrone drone;
	private final Logger logger;
	public TDrone() {
         telloControl = TelloControl.getInstance();
	     drone = TelloDrone.getInstance();
	     DestCoords = new ArrayList<Integer>();
	     HomeCoords = new ArrayList<Integer>();
	     DeliverFlag = false;
	     StopFlight = false;
	     telloControl.connect();
	     logger = Logger.getGlobal(); 
	     telloControl.setLogLevel(Level.FINE);
	}
	public void takeOff() {
		logger.info("start");
		telloControl.startStatusMonitor();
			telloControl.enterCommandMode();
			telloControl.takeOff();
		
		
	}
	
	public void Deliver(Integer f, Integer b, Integer l, Integer r, Integer u, Integer d) {
		DeliverFlag = true;
		if(StopFlight == false) {
		telloControl.forward(f);
	    HomeCoords.add(f);
	    telloControl.backward(b);
	    HomeCoords.add(b);
	    telloControl.up(u);
	    HomeCoords.add(u);
	    telloControl.down(d);
	    HomeCoords.add(d);
	    telloControl.left(l);
	    HomeCoords.add(l);
	    telloControl.right(r);
	    HomeCoords.add(r);
	    telloControl.land();
		telloControl.startStatusMonitor();
		telloControl.enterCommandMode();
		telloControl.takeOff();
	    Return(f, b, l, r, u, d);
	    
		}
		else {
			System.out.println(HomeCoords.toString());
			telloControl.emergency();
		}
	    
	}
	
	public void Return(Integer b, Integer f, Integer r, Integer l, Integer d, Integer u) {
		
		telloControl.forward(f);
	    HomeCoords.add(f);
	    telloControl.backward(b);
	    HomeCoords.add(b);
	    telloControl.up(u);
	    HomeCoords.add(u);
	    telloControl.down(d);
	    HomeCoords.add(d);
	    telloControl.left(l);
	    HomeCoords.add(l);
	    telloControl.right(r);
	    HomeCoords.add(r);
	    telloControl.land();
	    telloControl.disconnect();
		
	}
	
	public void FinishDelivery() {
		DeliverFlag = false;
		
	}
	
	
	public ArrayList<Integer> getDestCoords() {
		return DestCoords;
	}
	public void setDestCoords(ArrayList<Integer> destCoords) {
		DestCoords = destCoords;
	}
	public ArrayList<Integer> getHomeCoords() {
		return HomeCoords;
	}
	public void setHomeCoords(ArrayList<Integer> homeCoords) {
		HomeCoords = homeCoords;
	}
	public boolean isDeliverFlag() {
		return DeliverFlag;
	}
	public void setDeliverFlag(boolean deliverFlag) {
		DeliverFlag = deliverFlag;
	}

}
