package pharmaDrone;

public class FlyHigh {
	public static void main(String[] args) {
		TDrone td = new TDrone();
		td.takeOff();
		td.Deliver(20, 20, 20, 80, 20, 20);
		//td.Return(20, 20, 20, 80, 20, 20);
		
	}

}
