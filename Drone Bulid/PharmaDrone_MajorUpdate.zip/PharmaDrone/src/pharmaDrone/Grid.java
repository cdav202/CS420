package pharmaDrone;
import java.awt.*;
import javax.swing.*;

public class Grid extends JComponent{
	public Grid() {
		setSize(765,160);
		setVisible(true);
	}
//creates a grid with 5x5 squares
	public void paint(Graphics grid) {
		for (int x=0; x<=765; x+=10) {
			for (int y=0; y<=160; y+=10) {
				grid.setColor(Color.green);
				grid.drawRect(x, y, 10, 10);
			}
		}
	}
}
