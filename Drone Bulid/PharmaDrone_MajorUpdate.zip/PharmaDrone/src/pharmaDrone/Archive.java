package pharmaDrone;

import java.util.ArrayList;

import javax.swing.JFrame;

public class Archive {
	
	private ArrayList<Report> ArcLog;
	private int dailyDeliver;
	
	public Archive() {
		ArcLog = new ArrayList<Report>();
		this.setDailyDeliver(ArcLog.size());
	
	}
    public void addArchiveEntry(Report r) {
     ArcLog.add(r);
     this.setDailyDeliver(ArcLog.size());
    }
	
    public int getSize() {
    	return ArcLog.size();
    }
	public Report getArchiveEntry(int index) {
		return ArcLog.get(index);
	}

	public int getDailyDeliver() {
		return dailyDeliver;
	}
	public void setDailyDeliver(int dailyDeliver) {
		this.dailyDeliver = dailyDeliver;
	}
    public void clearArc() {
    	ArcLog.clear();
    	setDailyDeliver(ArcLog.size());
    }
    public void reveal() {
    	
    	
    }
}
