package pharmaDrone;


import javax.swing.table.AbstractTableModel;

public class ArcTableModel extends AbstractTableModel {
   private Archive BigArc;
   private String[] ColNames = new String[] {"Name", "Address", "Coords", "DateTime", "OrderNum", "MedType"};
    public ArcTableModel(Archive arc) {
    	this.BigArc = arc;
    }
    public Archive getArc() {
    	return BigArc;
    }
	
    @Override
 	  public String getColumnName(int column) {
 	        return ColNames[column];
 	    }
     
    @Override
	public int getRowCount() {
		return BigArc.getSize();

	}

	@Override
	public int getColumnCount() {
		return ColNames.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Report pluck = getArc().getArchiveEntry(rowIndex);
		switch (columnIndex) {
        case 0:
            return pluck.getName();
        case 1:
            return pluck.getAdd();
        case 2:
            return pluck.getCoords();
        case 3:
            return pluck.getDateTime();
        case 4:
            return pluck.getOrderNum();
        case 5:
            return pluck.getMedType();
      
    }
		return null;
	}

}
