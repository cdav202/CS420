package pharmaDrone;

public class Coordinates {
	public Coordinates(int x, int y){
	}
	
	private int cordsToXY(int cords) {
		//TODO :finish returning x and y 
		return 1;
	}
}
