package lab03;

import static org.junit.Assert.*;

import org.junit.Test;

public class Lab03JUnit {

	@Test
	public void testUnitTestingFunction() {
		assertEquals(20, Lab03.unitTestingFunction(10));
		assertEquals( 125, Lab03.unitTestingFunction(200));
		assertEquals(1, Lab03.unitTestingFunction(1));
		assertEquals(112, Lab03.unitTestingFunction(50));
	}

}
