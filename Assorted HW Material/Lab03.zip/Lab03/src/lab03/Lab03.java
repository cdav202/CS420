package lab03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Lab03 {
	public static int unitTestingFunction (int input) {
		List<Integer> numList=new ArrayList<Integer>();
		for (int i=1; i<=input; i++) {
			int cycle=1;
			int num=i;
			
			while (num!=1) {
				if (num%2==0) {
					num=num/2;
				}else {
					num=3*num+1;
				}
				cycle++;
			}
		numList.add(cycle);
		}
		return Collections.max(numList);
	}
}
