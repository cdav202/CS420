package lab03;

import java.util.Scanner;

public class Lab03Tester {
	public static void main (String [] args){
		Scanner userscanner= new Scanner(System.in);
		System.out.println("Enter the first number:");
		int userinput1=userscanner.nextInt();
		System.out.println("Enter the second number:");
		int userinput2=userscanner.nextInt();
		System.out.print(userinput1+ " "+userinput2+ " ");
		System.out.print(Lab03.unitTestingFunction(userinput2)+ "\n");
	}
}
