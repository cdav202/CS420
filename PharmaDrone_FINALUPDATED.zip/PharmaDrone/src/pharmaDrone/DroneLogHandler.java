package pharmaDrone;

import java.util.logging.Handler;
import java.util.logging.LogRecord;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

/*
 * This is a essentially a helper class that will connect a TextPane(my log) to the drone's logger functions.
 */
public class DroneLogHandler extends Handler {
	 private JTextPane myLog;
	public DroneLogHandler(JTextPane logPage) {
		 myLog = logPage;
	 }

	/*  Creates a Document where the LogRecords will be written onto the JTextPane
	 * 
	 */
	
	@Override
	public void publish(LogRecord record) {
		
        try {
        	Document doc = myLog.getDocument();
			doc.insertString(doc.getLength(), record.getMessage() + "\n", null);
			myLog.setCaretPosition(doc.getLength());
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() throws SecurityException {
		// TODO Auto-generated method stub
		
	}

}
