package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;

// Starts the System by creating the log in screen.
// Please ensure that you've added the Tello-SDK package that I've included with this project
// As I've written a new function TelloControl.getLog() which is important for the logging system to work
public class pharmadroneSystem extends JFrame{

	public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						AdminLogin frame = new AdminLogin();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}

}
