package pharmaDrone;

public class Report {
	private String name; 
	private String address;
	private String coords;
	private String DateTime;
	private String OrderNum;
	private String MedType;
	
	
	public Report(String n, String a, String c, String d, String o, String m) {
		this.setName(n);
		this.setAddress(a);
		this.setCoords(c);
		this.setDateTime(d);
		this.setOrderNum(o);
		this.setMedType(m);
	}
	public String toString() {
		String report = "Name: " + this.getName() + " Order: " + this.getOrderNum() + " Medication: " + this.getMedType()  + " addressress: " + this.getAddress() + "/" + this.getCoords() + " Date Delivered: " + this.getDateTime();
        return report;	
	}
	
	public boolean isIncomplete() {
		if(this.getName() == "" || this.getAddress() == "" || this.getCoords() == null|| this.getDateTime() == "" || this.getMedType() == "" || this.getOrderNum() == "") {
			return true;
		}
		else {
			return false;
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String add) {
		address = add;
	}
	public String getCoords() {
		return coords;
	}
	public void setCoords(String coords) {
		this.coords = coords;
	}
	public String getDateTime() {
		return DateTime;
	}
	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
	public String getOrderNum() {
		return OrderNum;
	}
	public void setOrderNum(String orderNum) {
		OrderNum = orderNum;
	}
	public String getMedType() {
		return MedType;
	}
	public void setMedType(String medType) {
		MedType = medType;
	}
}
