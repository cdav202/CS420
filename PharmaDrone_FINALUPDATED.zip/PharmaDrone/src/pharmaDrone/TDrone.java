package pharmaDrone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
// For this import, please make sure you add the Tello-SDK I included to the bulidpath of the PharmaDrone Project, as I have slightly edited this class!
import tellolib.control.TelloControl;
import tellolib.drone.TelloDrone;
public class TDrone {
	private ArrayList<Integer> destinationCoords;
	private ArrayList<Integer> homeCoords;
	private boolean DeliverFlag;
	private boolean stopFlight;
	TelloControl telloControl;
	TelloDrone drone;
	private final Logger logger;
	
/* Intializes the drone's controller (telloControl and drone) 
 * 	its booleans (DeliverFlag and isFlightStopped)
 *  and a logger.
 */
	public TDrone() {
         telloControl = TelloControl.getInstance();
	     drone = TelloDrone.getInstance();
	     destinationCoords = new ArrayList<Integer>();
	     homeCoords = new ArrayList<>(Collections.nCopies(6, 0));
	     DeliverFlag = false;
	     stopFlight = false;
	     telloControl.connect();
	     logger = Logger.getGlobal(); 
	}
	
	/*
	 * Sets up the drone to fly and for its movement to be logged through
	 * telloControl. If the drone's battery is too low, not connected, or is already doing a Delivery it will not fly.
	 */
	public void takeOff() {
	logger.info("Taking off..");
	 telloControl.setLogLevel(Level.FINE);
	 telloControl.startStatusMonitor();
	 telloControl.enterCommandMode();
	 if(drone.getBattery() > 5 && drone.isConnected() == true && isDeliverFlag() == false) {
	 telloControl.takeOff();
	 }
	 else {
		 logger.info("Refusal to fly initated, please make sure drone is in optimal condition before delivering.");
	 }
		
		
	}
	
	/*Using tellocontrol, pilot the drone.
	 * If stopFlight hasn't been called and the Integer's value is not 0,
	 * initate the movement and add the coordinates to homeCoords
	 */
	
	public void Deliver(Integer f, Integer b, Integer l, Integer r, Integer u, Integer d) {
		DeliverFlag = true;
		logger.info("Delivery Started.");
		if(stopFlight == false && f > 0) {
		telloControl.forward(f);
	    homeCoords.add(0, f);
		}
		 if(stopFlight == false && r > 0) {
			    telloControl.right(r);
			    homeCoords.add(3, r);
			   }
		
	    if(stopFlight == false && b > 0) {
	    telloControl.backward(b);
	    homeCoords.add(1, b);
	    }
	    
	   if(stopFlight == false && l > 0) {
	    telloControl.left(l);
	    homeCoords.add(2, l);
	   }
	
	  
	   if(stopFlight == false && u > 0) { 
	   telloControl.up(u);
	    homeCoords.add(4, u);
	   }
	    
	   if(stopFlight == false && d > 0) { 
	   telloControl.down(d);
	    homeCoords.add(5, d);
	   }
	   

	    telloControl.land();
	    Return(homeCoords.get(0), homeCoords.get(1), homeCoords.get(2), homeCoords.get(3), homeCoords.get(4), homeCoords.get(5));
	    
		}
		
	    
	/* Use the coordinates in homeCoords created by deliver() to return back to base.
	 * 
	 */
	
	public void Return(Integer b, Integer f, Integer r, Integer l, Integer d, Integer u) {
		logger.info("Beginning return flight.");
		telloControl.enterCommandMode();
        telloControl.startStatusMonitor();
		telloControl.takeOff();
		if(u > 0) {
		telloControl.up(u);
		}
		if(d > 0) {
	    telloControl.down(d);
		}
		 if(r > 0 ) {
			    telloControl.right(r);
			    }
		 if(f > 0) {
			    telloControl.forward(f);
			    }
	    if (l > 0) {
	    telloControl.left(l);
	    }
	   
	 
	    if(b > 0) {
	    telloControl.backward(b);
	    }
	    telloControl.land();
	    telloControl.disconnect();
	    FinishDelivery();
	}
	
	/* Sets booleans to false and offically announced the delivery complete
	 * Added a reminder for the operator to immediately create a Report.
	 */
	public void FinishDelivery() {
		DeliverFlag = false;
		stopFlight = false;
		logger.info("Delivery Complete. Please hit the archive button and create a report for this delivery.");
		
	}
	public TelloControl getTC() {
		return telloControl;
	}
	
	public ArrayList<Integer> getDestCoords() {
		return destinationCoords;
	}
	public void setDestCoords(ArrayList<Integer> destCoords) {
		destinationCoords = destCoords;
	}
	public ArrayList<Integer> gethomeCoords() {
		return homeCoords;
	}
	public void sethomeCoords(ArrayList<Integer> hc) {
		homeCoords = hc;
	}
	public boolean isDeliverFlag() {
		return DeliverFlag;
	}
	public void setDeliverFlag(boolean deliverFlag) {
		DeliverFlag = deliverFlag;
	}
	public void setstopFlight(boolean emergency) {
		stopFlight = emergency;
	}
	public Logger getLog() {
		return logger;
	}
	

	}


