package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.Label;
import java.awt.GridLayout;
import javax.swing.JScrollPane;
import javax.swing.SwingWorker;
public class PharmaDroneUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField coordinateTextBox;
	private JFrame frame;
	private ArchiveInfoInsertion reportArchiveInfoPage= new ArchiveInfoInsertion();
	private TDrone drone;
	

	/**
	 * Launch the application.
	 */
	public static void NewFrame( ) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					PharmaDroneUI frame = new PharmaDroneUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/*
	 * get the JFrame of this object
	 */
	public JFrame getFrame() {
		  return frame;
	  }
	
	/* Turn a string of 6 digits into a ArrayList to be used for the drone
	 * by using String.split and a for loop
	 */
	public static ArrayList<Integer> stringtoCoords(String str){
		String[] stringArray = str.split(",\\s*");
        if(stringArray.length != 6) {
        	return null;
        }
        ArrayList<Integer> coords = new ArrayList<Integer>();
        for (int i = 0; i < stringArray.length; i++) {
        	Integer num = Integer.valueOf(stringArray[i].trim());
            if(num > 500 || (num < 20 && num > 0)){
            	coords.add(0);
            }
            else {
        	coords.add(num);
            }
        }
      
        return coords;
		
	}
	
	/**
	 * Create the frame.
	 */
	public PharmaDroneUI() {
		
		// basic outline
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
		setTitle("Pharmadrone System");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
	// creating the message box and attaching it to a Handler
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 11, 764, 234);
		contentPane.add(scrollPane_1);
		
		Label messageLogBox = new Label("Message Log:");
		scrollPane_1.setColumnHeaderView(messageLogBox);
		
		JTextPane messageBox = new JTextPane();
		scrollPane_1.setViewportView(messageBox);
		messageBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
	
		DroneLogHandler droneLog = new DroneLogHandler(messageBox);
       
		
 /* Creating the Deliver Button
  * When pushed, it will initate a delivery using the statements in coordinateTextBox
  * and turn it into an ArrayList that makes up its destination coordinates.
  */
		
		JButton deliverButton = new JButton("Deliver\r\n");
		deliverButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		deliverButton.setBounds(288, 363, 100, 50);
		contentPane.add(deliverButton);
		deliverButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String coordStr = coordinateTextBox.getText();
				ArrayList<Integer> coordList = stringtoCoords(coordStr);
			// will also send the coordinates for this delivery to the Archive page for use
				reportArchiveInfoPage.setlastDeliveryCoords(coordStr);
				  SwingWorker<Void, Void> deliveryRun = new SwingWorker<Void, Void>() {
				        @Override
				        protected Void doInBackground() throws Exception {
				        	drone = new TDrone();
				        	drone.getLog().addHandler(droneLog);
				            drone.getTC().getLog().addHandler(droneLog);
				            if(coordList != null) {
				            drone.setDestCoords(coordList);
				            drone.takeOff();
				            drone.Deliver(drone.getDestCoords().get(0), drone.getDestCoords().get(1), drone.getDestCoords().get(2), drone.getDestCoords().get(3), drone.getDestCoords().get(4), drone.getDestCoords().get(5));
				            drone.getLog().removeHandler(droneLog);
				            drone.getTC().getLog().removeHandler(droneLog);
				           
				            }
				            return null;
				        }
				    };
				    deliveryRun.execute();
				    reportArchiveInfoPage.setlastDeliveryCoords(coordStr);
			}
		});
		
// creating the coordinate Textbox
		coordinateTextBox = new JFormattedTextField();
		coordinateTextBox.setBackground(new Color(255, 255, 255));
		coordinateTextBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		coordinateTextBox.setHorizontalAlignment(SwingConstants.CENTER);
		coordinateTextBox.setText("\r\n");
		coordinateTextBox.setBounds(10, 288, 654, 42);
		contentPane.add(coordinateTextBox);
		coordinateTextBox.setColumns(10);
		
		JButton logoutButton = new JButton("Logout");
		logoutButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		logoutButton.setBounds(674, 429, 100, 21);
		contentPane.add(logoutButton);
		//creates the Login Page
		logoutButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(true);
				dispose();
				AdminLogin login= new AdminLogin();
				login.NewFrame();
			}
		});
				
/* Creating the Return button.
 * If pushed, it will set the drone's stopFlight boolean to false, 
 * triggering an emergency recall of the drone.
 * 		
 */
		JButton returnButton = new JButton("Return\r\n");
		returnButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		returnButton.setBounds(10, 363, 100, 50);
		contentPane.add(returnButton);
		returnButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(drone.isDeliverFlag() == true) {
					drone.getLog().info("Emergency Stop Called! Stopping.....");
					drone.setstopFlight(true);
				}
			}
		});
		
		
		// Creating a label directing the operator to enter coordinates
		Label coordinateLabel = new Label("Please enter coordinates:");
		coordinateLabel.setBounds(10, 251, 230, 21);
		contentPane.add(coordinateLabel);
		
		
/* Creates the Archive Button, if pushed, takes you to the Archive page 
 * represented by the ArchiveInfoInsertion object.
 * 		
 */
		JButton archiveButton = new JButton("Archive");
		archiveButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		archiveButton.setBounds(564, 365, 100, 49);
		contentPane.add(archiveButton);
		
		archiveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(true);
				reportArchiveInfoPage.getFrame().setVisible(true);
			}
		});
		
	
		
		
	}
}
