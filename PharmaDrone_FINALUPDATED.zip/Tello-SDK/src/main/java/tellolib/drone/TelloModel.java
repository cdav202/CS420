package tellolib.drone;

/**
 * Enum describing the Tello drone models.
 */
public enum TelloModel
{
	Basic,
	EDU
}
