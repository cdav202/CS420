package tellolib.communication;

public enum TelloConnection {
  CONNECTED,
  DISCONNECTED
}
