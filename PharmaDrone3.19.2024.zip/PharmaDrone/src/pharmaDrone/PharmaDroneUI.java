package pharmaDrone;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.Label;
import java.awt.GridLayout;

public class PharmaDroneUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField coordinateTextBox;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					PharmaDroneUI frame = new PharmaDroneUI();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public PharmaDroneUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel droneMap = new JPanel();
		droneMap.setBackground(new Color(156, 223, 226));
		droneMap.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		droneMap.setBounds(10, 32, 414, 102);
		contentPane.add(droneMap);
		droneMap.setLayout(new GridLayout(1, 0, 0, 0));
		
		JButton deliverButton = new JButton("Deliver\r\n");
		deliverButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		deliverButton.setBounds(120, 200, 100, 50);
		contentPane.add(deliverButton);
		
		coordinateTextBox = new JTextField();
		coordinateTextBox.setBackground(new Color(255, 255, 255));
		coordinateTextBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		coordinateTextBox.setHorizontalAlignment(SwingConstants.CENTER);
		coordinateTextBox.setText("\r\n");
		coordinateTextBox.setBounds(10, 164, 210, 25);
		contentPane.add(coordinateTextBox);
		coordinateTextBox.setColumns(10);
		
		JTextPane messageBox = new JTextPane();
		messageBox.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		messageBox.setBounds(245, 164, 179, 86);
		contentPane.add(messageBox);
		
		JButton logoutButton = new JButton("Logout");
		logoutButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		logoutButton.setBounds(10, 0, 100, 21);
		contentPane.add(logoutButton);
		
		JPanel seperator = new JPanel();
		seperator.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		seperator.setBackground(new Color(170, 171, 191));
		seperator.setBounds(231, 135, 4, 126);
		contentPane.add(seperator);
		
		JButton returnButton = new JButton("Return\r\n");
		returnButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		returnButton.setBounds(10, 200, 100, 50);
		contentPane.add(returnButton);
		
		Label coordinateLabel = new Label("Please enter coordinates:");
		coordinateLabel.setBounds(10, 135, 131, 21);
		contentPane.add(coordinateLabel);
		
		Label messageLogBox = new Label("Message Log:");
		messageLogBox.setBounds(245, 137, 76, 21);
		contentPane.add(messageLogBox);
		
		JButton archiveButton = new JButton("Archive");
		archiveButton.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 10));
		archiveButton.setBounds(324, -1, 100, 21);
		contentPane.add(archiveButton);
	}
}
